
import streamlit as st


def display_persona(persona):

    with st.container(border=True):

        st.subheader(f"👤 {persona['name']}")

        st.write(
            f"{persona['age']} years old | "
            f"{persona['occupation']}"
        )

        st.caption(f"📍 {persona['location']}")

        st.divider()

        st.write("**Customer Interests**")
        st.write(", ".join(persona["interests"]))

        st.write("**Purchase Behaviour**")

        st.write(
            f"Purchase frequency: "
            f"{persona['purchase_frequency']}"
        )

        st.write(
            f"Preferred channel: "
            f"{persona['preferred_channel']}"
        )

        st.write(
            f"Price sensitivity: "
            f"{persona['price_sensitivity']}"
        )

        st.write(
            f"Purchase motivation: "
            f"{persona['purchase_motivation']}"
        )

        st.write(
            f"Purchase barrier: "
            f"{persona['purchase_barrier']}"
        )

        st.divider()

        st.metric(
            "Purchase Likelihood",
            f"{persona['purchase_likelihood']}%"
        )

        st.write(
            f"**Sentiment:** {persona['sentiment']}"
        )

        st.caption(
            f"Estimated budget: ₹{persona['budget']:,}"
        )

        with st.expander("View Customer Feedback"):
            st.write(persona["feedback"])
