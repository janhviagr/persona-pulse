
import streamlit as st

st.set_page_config(
    page_title="Product Submission | PersonaPulse",
    page_icon="📦",
    layout="wide"
)

st.title("📦 Product Submission")
st.write("Enter your product details to begin consumer testing.")

st.divider()

# PRODUCT SUBMISSION FORM

with st.form("product_submission_form"):

    st.subheader("1. Product Information")

    product_name = st.text_input(
        "Product Name",
        placeholder="Example: FitTrack Smartwatch"
    )

    description = st.text_area(
        "Product Description",
        placeholder="Describe what your product does..."
    )

    category = st.selectbox(
        "Product Category",
        [
            "Wearable Technology",
            "Electronics",
            "Fashion",
            "Food and Beverage",
            "Healthcare",
            "Fitness",
            "Other"
        ]
    )

    col1, col2 = st.columns(2)

    with col1:
        price = st.number_input(
            "Product Price",
            min_value=0.0,
            value=4999.0,
            step=100.0
        )

    with col2:
        currency = st.selectbox(
            "Currency",
            ["INR", "USD", "EUR"]
        )

    features = st.text_area(
        "Key Product Features",
        placeholder="Enter one feature per line..."
    )

    st.divider()

    st.subheader("2. Target Audience")

    audience = st.multiselect(
        "Select target age groups",
        ["18–24", "25–34", "35–44", "45–54", "55+"],
        default=["18–24", "25–34"]
    )

    interests = st.multiselect(
        "Select consumer interests",
        [
            "Fitness",
            "Technology",
            "Fashion",
            "Health",
            "Lifestyle",
            "Budget Shopping"
        ]
    )

    st.divider()

    st.subheader("3. Simulation Configuration")

    persona_count = st.slider(
        "Number of synthetic personas",
        min_value=10,
        max_value=100,
        value=50,
        step=10
    )

    submitted = st.form_submit_button(
        "Submit Product",
        type="primary",
        use_container_width=True
    )


# PROCESS FORM SUBMISSION

if submitted:

    if not product_name.strip():
        st.error("Please enter a product name.")

    elif not description.strip():
        st.error("Please enter a product description.")

    elif not audience:
        st.error("Please select at least one target age group.")

    else:

        product = {
            "name": product_name,
            "description": description,
            "category": category,
            "price": price,
            "currency": currency,
            "features": [
                f.strip()
                for f in features.split("\n")
                if f.strip()
            ],
            "target_audience": audience,
            "interests": interests,
            "persona_count": persona_count
        }

        st.session_state["product"] = product

        # Clear previously generated personas
        st.session_state.pop("personas", None)

        st.success("Product submitted successfully!")


# DISPLAY SUBMITTED PRODUCT

if "product" in st.session_state:

    product = st.session_state["product"]

    st.divider()

    st.subheader("✅ Product Summary")

    col1, col2 = st.columns(2)

    with col1:
        st.write(f"**Product:** {product['name']}")
        st.write(f"**Category:** {product['category']}")
        st.write(f"**Price:** {product['currency']} {product['price']:,.2f}")

    with col2:
        st.write("**Target Audience:**")
        st.write(", ".join(product["target_audience"]))

        st.write("**Interests:**")
        st.write(", ".join(product["interests"]) or "Not specified")

    st.write("**Product Features:**")
    st.write(", ".join(product["features"]) or "Not specified")

    st.write(
        f"**Requested Personas:** {product['persona_count']}"
    )

    st.divider()

    if st.button(
        "Continue to Persona Generation →",
        type="primary",
        use_container_width=True
    ):
        st.switch_page("pages/2_Persona_Generation.py")
