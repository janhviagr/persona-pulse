
import streamlit as st
import random
import time

st.set_page_config(
    page_title="PersonaPulse - Simulation",
    page_icon="🧪",
    layout="wide"
)

st.title("🧪 Product Simulation")
st.write("Let your synthetic customers evaluate your product.")

# Check whether product and personas exist
product = st.session_state.get("product")
personas = st.session_state.get("personas", [])

if not product or not personas:
    st.warning("Please submit a product and generate personas first.")
    if st.button("Go to Persona Generation"):
        st.switch_page("pages/2_Persona_Generation.py")
    st.stop()

st.subheader("Product Under Evaluation")

st.write(f"**Product:** {product.get('name', 'Unnamed Product')}")
st.write(f"**Description:** {product.get('description', 'No description')}")

st.divider()

st.subheader("Simulation Configuration")

st.write(f"Total personas participating: **{len(personas)}**")

st.write(
    "Each persona will provide simulated evaluations "
    "of purchase intent, product appeal, pricing and recommendation likelihood."
)

# Run simulation
if st.button("🚀 Start Simulation", type="primary"):

    progress = st.progress(0)
    status = st.empty()

    results = []
    random.seed(42)

    for index, persona in enumerate(personas):

        likelihood = int(persona.get("purchase_likelihood", 50))

        # Generate simulated evaluation scores
        purchase_intent = max(
            0, min(100, likelihood + random.randint(-8, 8))
        )

        product_appeal = max(
            0, min(100, likelihood + random.randint(-12, 12))
        )

        price_acceptance = max(
            0, min(100, likelihood + random.randint(-15, 10))
        )

        recommendation_intent = max(
            0, min(100, likelihood + random.randint(-10, 10))
        )

        usability_score = random.randint(55, 95)

        result = {
            "persona": persona,
            "purchase_intent": purchase_intent,
            "product_appeal": product_appeal,
            "price_acceptance": price_acceptance,
            "recommendation_intent": recommendation_intent,
            "usability_score": usability_score
        }

        results.append(result)

        progress.progress((index + 1) / len(personas))
        status.write(
            f"Evaluating persona {index + 1} of {len(personas)}..."
        )

        time.sleep(0.03)

    st.session_state["simulation_results"] = results

    status.success("Simulation completed successfully!")
    st.rerun()


# Display results after simulation
results = st.session_state.get("simulation_results")

if results:

    st.divider()
    st.subheader("Simulation Overview")

    total = len(results)

    avg_purchase = sum(
        r["purchase_intent"] for r in results
    ) / total

    avg_appeal = sum(
        r["product_appeal"] for r in results
    ) / total

    avg_price = sum(
        r["price_acceptance"] for r in results
    ) / total

    avg_recommendation = sum(
        r["recommendation_intent"] for r in results
    ) / total

    col1, col2, col3, col4 = st.columns(4)

    col1.metric("Personas Evaluated", total)
    col2.metric("Purchase Intent", f"{avg_purchase:.1f}%")
    col3.metric("Product Appeal", f"{avg_appeal:.1f}%")
    col4.metric("Price Acceptance", f"{avg_price:.1f}%")

    st.metric(
        "Recommendation Intent",
        f"{avg_recommendation:.1f}%"
    )

    st.divider()
    st.subheader("Individual Persona Evaluations")

    for result in results:

        persona = result["persona"]

        with st.expander(
            f"{persona['name']} — "
            f"{result['purchase_intent']}% Purchase Intent"
        ):

            st.write(
                f"**Occupation:** {persona.get('occupation', 'N/A')}"
            )

            st.write(
                f"**Purchase Motivation:** "
                f"{persona.get('purchase_motivation', 'N/A')}"
            )

            st.write(
                f"**Purchase Barrier:** "
                f"{persona.get('purchase_barrier', 'N/A')}"
            )

            st.write(
                f"**Purchase Intent:** {result['purchase_intent']}%"
            )

            st.write(
                f"**Product Appeal:** {result['product_appeal']}%"
            )

            st.write(
                f"**Price Acceptance:** {result['price_acceptance']}%"
            )

            st.write(
                f"**Recommendation Intent:** "
                f"{result['recommendation_intent']}%"
            )

            st.write(
                f"**Usability Score:** {result['usability_score']}%"
            )

    st.divider()

    if st.button("📊 Continue to Analytics Dashboard", type="primary"):
        st.switch_page("pages/4_Analytics.py")
