
import streamlit as st

st.set_page_config(
    page_title="PersonaPulse",
    page_icon="🎯",
    layout="wide"
)

# Custom styling
st.markdown("""
<style>
.hero {
    padding: 35px;
    border-radius: 15px;
    background: linear-gradient(120deg, #172554, #4338ca);
    color: white;
    text-align: center;
}
.hero h1 {
    font-size: 42px;
    color: white;
}
.hero p {
    font-size: 18px;
    color: #e0e7ff;
}
</style>
""", unsafe_allow_html=True)

# Sidebar
with st.sidebar:
    st.title("🎯 PersonaPulse")
    st.caption("Synthetic Consumer Intelligence")
    st.divider()
    st.write("AI-powered product validation")

# Landing page
st.markdown("""
<div class="hero">
    <h1>PersonaPulse</h1>
    <p>Understand your customers before launching your product.</p>
    <p>Simulate consumer responses using AI-generated personas.</p>
</div>
""", unsafe_allow_html=True)

st.write("")
st.subheader("What can you do with PersonaPulse?")

col1, col2, col3 = st.columns(3)

with col1:
    st.subheader("📦 Product Testing")
    st.write("Submit products and test their market potential.")

with col2:
    st.subheader("👥 Consumer Personas")
    st.write("Explore different synthetic customer profiles.")

with col3:
    st.subheader("📊 Market Insights")
    st.write("Understand consumer preferences and sentiment.")

st.divider()

st.subheader("Getting Started")
st.write("Start by submitting your product details.")

if st.button("Start Product Submission", type="primary"):
    st.switch_page("pages/1_Product_Submission.py")

st.caption("PersonaPulse | Synthetic User Persona Swarm")
